class Movie
  attr_accessor :title, :director, :year, :id
end
